SIDIKMA 26 HOTFIX SQLSTATE 1906

Tujuan
Memperbaiki proses approval Usulan SK Baru ketika database hosting memiliki
kolom users.name sebagai generated column.

File yang diganti
app/Services/DecreeProposalApprovalService.php

Perubahan
Service membaca metadata kolom users melalui Schema::getColumns() dan tidak
mengirim kolom yang memiliki metadata generation pada INSERT. nama_lengkap
tetap dikirim sebagai sumber nilai generated column.

Validasi
- Approval SQLite disposable: 1 test, 11 assertions, PASS.
- Probe generated column SQLite disposable: 1 test, 4 assertions, PASS.
- MariaDB/MySQL hosting aktual: NOT RUN; metadata hosting belum diakses langsung.
- Email nyata: tidak dikirim; notification di-fake saat test.

Deployment manual
1. Backup file service yang sedang aktif.
2. Ganti file sesuai struktur folder paket.
3. Bersihkan cache aplikasi sesuai prosedur hosting yang berlaku.
4. Uji satu proposal baru yang belum pernah disetujui.
5. Periksa User, Employee, Membership, EmployeeAssignment, status proposal,
   dan reset password sebelum mengulang approval apa pun.

Tidak termasuk
Database, migration, seeder, .env, vendor, UI V8, Presensi, GPS, autentikasi,
policy, permission, route, dan modul lain.
